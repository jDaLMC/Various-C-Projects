#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/inotify.h>
#include <sys/epoll.h>

// Define the maximum number of events to read at a time.
#define MAX_EVENTS 64
#define TAG_MAX_LENGTH 50
#define MAX_WATCHES 100

// Define the length of the event buffer.
#define EVENT_BUF_LEN (MAX_EVENTS * (sizeof(struct inotify_event) + NAME_MAX + 1))

// Global flag
int running;

// Signal handler
void handler(int sig) {
    running = 0;
}

struct WatchTagMapping {
    int watch_descriptor;
    char tag[TAG_MAX_LENGTH];
};

// Function to handle inotify events
void handle_inotify_event(int inotify_fd, struct WatchTagMapping watch_mapping[]) {
    char buffer[EVENT_BUF_LEN];
    char file_tag[256];
    int bytesRead = read(inotify_fd, buffer, EVENT_BUF_LEN);
    if (bytesRead == -1) {
        perror("read");
        break;
    }
    struct inotify_event *event = (struct inotify_event *)buffer;

    // Watch descriptor
    int watchFd = event->wd;
    for (int i = 0; i < MAX_WATCHES; i++) {
        if (watch_mapping[i].watch_descriptor == watchFd) {
            /** Should be strcpy(file_tag,watch_mapping[i].tag); **/
            file_tag = watch_mapping[i].tag;
            // Get the current time
            time_t currentTime;
            time(&currentTime);
            char *timestamp = ctime(&currentTime);

            // Log the event with tag and timestamp
            FILE *logFile = fopen("fwd.log", "a");
            /** Write tag, file name, and time, not tag, mask, and time. **/
            fprintf(logFile, "Tag: %s, Event: %s, Timestamp: %s", file_tag, event->mask, timestamp);
            fclose(logFile);
            break;
        }
    }
}

int main() {
    // Initialize the running flag
    running = 1;

    // Initialize the tag and path variables
    char path[128];
    struct WatchTagMapping watch_mapping =(struct WatchTagMapping *)malloc(MAX_WATCHES * sizeof(struct WatchTagMapping));
    /** Put * in front of watch_mapping **/
    // Install signal handler
    struct sigaction sa;
    sa.sa_handler = handler;
    sa.sa_flags = 0;
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    // Open files
    FILE *configFile = fopen("/etc/fwd.conf", "r");
    FILE *logFile = fopen("/var/log/fwd.log", "a");

    /** Missing: char line[128]; **/
    // Count the number of lines in the configuration file
    int numLines = 0;
    while (fgets(line, sizeof(line), configFile) != NULL) {
        numLines++;
    }

    // Close and reopen the configuration file
    fclose(configFile);
    configFile = fopen("/etc/fwd.conf", "r");

    // Create an inotify instance
    int inotify_fd = inotify_init();
    if (inotify_fd == -1) {
        perror("inotify_init");
        exit(EXIT_FAILURE);
    }

    // Reading Configuration File and Adding Watches
    int i =0;
    while (fgets(line, sizeof(line), configFile) != NULL) {
        sscanf(line, "%s %s", watch_mapping[i].tag, path);
        watch_mapping[i].watch = inotify_add_watch(inotify_fd, path, IN_CREATE | IN_MODIFY);
        if (watch_mapping[i].watch == -1) {
            perror("inotify_add_watch");
            exit(EXIT_FAILURE);
        }
        i++;
    }

    fclose(configFile);

    // Create an epoll instance
    int epoll_fd = epoll_create(numLines);
    if (epoll_fd == -1) {
        perror("epoll_create");
        exit(EXIT_FAILURE);
    }

    // Add inotify file descriptor to epoll
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = inotify_fd;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, inotify_fd, &ev) == -1) {
        perror("epoll_ctl");
        exit(EXIT_FAILURE);
    }

    struct epoll_event events; /** Put * in front of events. **/
    while (running) {
        events = malloc(sizeof(struct epoll_event)*MAX_EVENTS);
        if (!events) {
             perror ("malloc");
             return 1;
        }

        int num_events = epoll_wait(epoll_fd, events, MAX_EVENTS, -1);
        if (num_events < 0) {
            if (errno == EINTR) {
                // epoll_wait interrupted by a signal
                continue;
            }
            perror("epoll_wait");
            free(events);
            exit(EXIT_FAILURE);
            return 1;
        }

        // Loop through the received events
        for (int i = 0; i < num_events; i++) {
            if (events[i].data.fd == inotify_fd) {
                // Handle inotify event
                handle_inotify_event(inotify_fd,watch_mapping[i].watch); /** Second parameter should be watch_mapping. **/
            }
        }
    }

    // Cleanup and close file descriptors
    free(events);
    close(epoll_fd);
    close(inotify_fd);

    return 0;
}


/** 138/150 **/
