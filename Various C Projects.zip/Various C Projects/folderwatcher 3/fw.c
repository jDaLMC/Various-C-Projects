#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <pthread.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

void serveRequest(char* path) {
    char lineBuffer[256];

    pid_t pid = fork();
    if (pid == 0) {
        char *const cmdArr[] = {"fwd",path, NULL};
        execve("./fwd", cmdArr, NULL);
    }

    FILE* openPath = fopen("paths.txt", "a");
    char strpid[20];
    snprintf(strpid, sizeof(strpid), "%d", pid);
    fwrite(strpid, sizeof(char), strlen(strpid), openPath);
    fputc('\n', openPath);
    fclose(openPath);
    waitpid(pid,NULL,0);
}

void killFWD(){
    FILE* openPath = fopen("paths.txt", "r");
    char pidStr[100];
    fgets(pidStr, sizeof(pidStr), openPath);
    fclose(openPath);
    pid_t pid = (pid_t)strtol(pidStr, NULL, 10);
    kill(pid,SIGKILL);
}

int main(int argc, char *argv[]) {
    char *action = argv[1];

    if(strcmp(action,"start") == 0){
        char *path = argv[2];
        serveRequest(path);
    } else {
        killFWD();
    }

}