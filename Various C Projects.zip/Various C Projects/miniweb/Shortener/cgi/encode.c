#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sqlite3.h>
#include <base64/base64.h>

int fromHex(char ch) {
  if(ch >= '0' && ch <= '9')
    return (int) ch - '0';
  return (int) ch - 'A' + 10;
}

void decodeURL(char* src,char* dest) {
  while(*src != '\0') {
    if(*src == '%') {
      ++src;
      int n1 = fromHex(*src++);
      int n2 = fromHex(*src++);
      *dest++ = (char) n1*16+n2;
    } else {
      *dest++ = *src++;
    }
  }
  *dest = '\0';
}

int main(void) {
	sqlite3 *db;
	int rc = sqlite3_open("cgi/urls.db", &db);

  char* lengthStr;
  if ((rc == SQLITE_OK) && ((lengthStr = getenv("CONTENT_LENGTH")) != NULL)) {
    // Get the content length
    int length;
    sscanf(lengthStr,"%d",&length);

    // Read the query from stdin
    char buffer[256];
    read(STDIN_FILENO,buffer,length);
    buffer[length] = '\0';
    // Isolate the url from the query string.
    char* url = buffer+4;
		decodeURL(url,buffer);

		// Store the URL in the database
		char *err_msg = 0;
		char sql[128];
		sprintf(sql,"INSERT INTO Urls(URL) VALUES('%s');",buffer);
		rc = sqlite3_exec(db, sql, NULL, 0, &err_msg);

		// Get the id number of the inserted entry
		sqlite3_int64 id = sqlite3_last_insert_rowid(db);

		// Encode the id number
		char code[7];
		encode((unsigned int) id,code);

    // Make the body of the response
    char content[1024];
    sprintf(content,"<!DOCTYPE html>\r\n");
    sprintf(content,"%s<head>\r\n",content);
    sprintf(content,"%s<title>URL shortening</title>\r\n",content);
    sprintf(content,"%s</head>\r\n",content);
    sprintf(content,"%s<body>\r\n",content);
		sprintf(content,"%s<h1>Your URL</h1>\r\n",content);
    sprintf(content,"%s<p>Your URL is http://localhost:8888/s/%s<\p>\r\n",content,code);
    sprintf(content,"%s</body>",content);

    // Send the response
    printf("HTTP/1.1 200 OK\r\n");
    printf("Connection: close\r\n");
    printf("Content-length: %d\r\n", (int)strlen(content));
    printf("Content-type: text/html\r\n\r\n");
    printf("%s", content);
    fflush(stdout);
  } else {
    // Send back an error response
    printf("HTTP/1.1 500 Internal Server Error\r\n");
    printf("Connection: close\r\n");
    printf("Content-length: 21\r\n");
    printf("Content-type: text/plain\r\n\r\n");
    printf("Something went wrong.");
    fflush(stdout);
  }
	sqlite3_close(db);
  return 0;
}
