#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sqlite3.h>
#include <base64/base64.h>

void errorResponse() {
	// Send back an error response
	printf("HTTP/1.1 500 Internal Server Error\r\n");
	printf("Connection: close\r\n");
	printf("Content-length: 21\r\n");
	printf("Content-type: text/plain\r\n\r\n");
	printf("Something went wrong.");
	fflush(stdout);
}

char URL[256];

int callback(void *NotUsed, int argc, char **argv, char **colNames) {
    if(argc > 0 && strcmp(colNames[0],"URL") == 0)
			strncpy(URL,argv[0],255); //argv has the actual data/url. we only have 1 callback so the [0] item is what we need. and then we put it into the buffer
		else
			URL[0] = '\0';

    return 0;
}

int main() {
	int status = 0;
	sqlite3 *db;
	int rc = sqlite3_open("cgi/urls.db", &db);

	char* codeStr;
	if ((rc == SQLITE_OK) && ((codeStr = getenv("QUERY_STRING")) != NULL) && (strncmp(codeStr,"code=",5)==0)) {
		unsigned int code = decode(codeStr+5);

		char *err_msg = 0;
		char sql[128];
		sprintf(sql,"SELECT URL from Urls WHERE id = %u;",code);
		//important technical sqlite callback
		rc = sqlite3_exec(db, sql, callback, 0, &err_msg); 
		if (rc != SQLITE_OK || URL[0] == '\0') {
			errorResponse();

			if(rc != SQLITE_OK)
      	sqlite3_free(err_msg);

      status = 1;
    } else { //this is where we send stuff back
	  printf("HTTP/1.1 301 Permanently Moved\n");
      printf("Location: ");
      printf("%s\r\n\r\n",URL);
      fflush(stdout);
		}
	} else {
		errorResponse();
		status = 1;
	}

  sqlite3_close(db);
	return status;
}
