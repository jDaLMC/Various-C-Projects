#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main(void) {
  char* lengthStr;
  //read environent variable with getenv and the name of the variable
  if ((lengthStr = getenv("CONTENT_LENGTH")) != NULL) {
    // Get the content length
    int length;
    sscanf(lengthStr,"%d",&length); //read length of the body from the env var
    // Read the query from stdin
    char buffer[256];
    //STDIN is to read from the socket with the size of body length. body sits in buffer
    read(STDIN_FILENO,buffer,length);
    buffer[length] = '\0';
    // Isolate the name from the query string. (searching for what we need)
    char* p = strchr(buffer, '&');
    *p = '\0';
    char* name = buffer+5;
    p = strchr(name,'+');
    if(p != NULL)
    *p = ' ';

    // Make the body of the response (by just printing every line)
    char content[1024];
    sprintf(content,"<!DOCTYPE html>\r\n");
    sprintf(content,"%s<head>\r\n",content);
    sprintf(content,"%s<title>Registration successful</title>\r\n",content);
    sprintf(content,"%s</head>\r\n",content);
    sprintf(content,"%s<body>\r\n",content);
    sprintf(content,"%s<p>Hello, %s. You are now registered.<\p>\r\n",content,name); //this is where we're inserting the person's name
    sprintf(content,"%s</body>",content);

    // Send the response (by using the printf commands)
    printf("HTTP/1.1 200 OK\r\n");
    printf("Connection: close\r\n");
    //sending this needs body size, so we need to build the body (which we did with sprintf) and getting its size
    printf("Content-length: %d\r\n", (int)strlen(content));
    printf("Content-type: text/html\r\n\r\n");
    printf("%s", content);
    fflush(stdout); //just gotta flush
  } else {
    // Send back an error response
    printf("HTTP/1.1 500 Internal Server Error\r\n");
    printf("Connection: close\r\n");
    printf("Content-length: 21\r\n");
    printf("Content-type: text/plain\r\n\r\n");
    printf("Something went wrong.");
    fflush(stdout);
  }
  return 0;
}
