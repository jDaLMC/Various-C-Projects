#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <pthread.h>
#include "queue.h"
#include "base64.h"

int fromHex(char ch) {
  if(ch >= '0' && ch <= '9')
    return (int) ch - '0';
  return (int) ch - 'A' + 10;
}

void decodeURL(char* src,char* dest) {
  while(*src != '\0') {
    if(*src == '%') {
      ++src;
      int n1 = fromHex(*src++);
      int n2 = fromHex(*src++);
      *dest++ = (char) n1*16+n2;
    } else {
      *dest++ = *src++;
    }
  }
  *dest = '\0';
}

void serveRequest(int fd) {
  // Read the request
  char buffer[1024];
	int bytesRead = read(fd,buffer,1023);
  buffer[bytesRead] = '\0';

  // Grab the method and URL
  char method[16];
  char url[128];
  sscanf(buffer,"%s %s",method,url);

  if (method == "POST")
  {
    // Taking URL and decoding it
    char* pattern = "\r\n\r\nurl=";
    char* ulrPostPosition = strstr(buffer, pattern);
    char* encodedURL = ulrPostPosition + strlen(pattern);
    char decodedURLArr[1024];
    decodeURL(encodedURL,decodedURLArr);

    // Putting the decoded URL into a text file
    FILE* urlfile = fopen("urls.txt", "w");
    long currentPos = ftell(urlfile); // Current position in file
    int lastIndex = (sizeof(decodedURLArr) / sizeof(decodedURLArr[0])) - 1; // Calculate the index of the last item
    // Write the last extracted string to the file
    const char* addThisURL = &decodedURLArr[lastIndex];
    fwrite(addThisURL, sizeof(char), strlen(addThisURL), urlfile);
    fputc('\n', urlfile); // Add a newline after the string

    // Creating new URL
    char newURLS[1024];
    encode(currentPos,newURLS);
    fclose(urlfile);

    // Open POST response file and read into buffer
    int fpost = open("post.txt",O_RDWR);
    char postbuffer[1024];
    int readSize = read(fpost,postbuffer,1023);
    postbuffer[readSize] = '\0';
    int lastNewURL = (sizeof(newURLS) / sizeof(newURLS[0])) - 1; // Calculate the index of the last item in the new URLs array

    // Finding the position to put the new URL into in the post.txt
    ulrPostPosition = strstr(postbuffer, "XXXXXX");
    size_t offset = ulrPostPosition - buffer;
    lseek(fpost, offset, SEEK_SET); // Finding string in text file
    const char* lastNewURLInArray = &newURLS[lastNewURL];
    write(fpost, lastNewURLInArray, strlen(lastNewURLInArray)); // Write the new URL over XXXXXX
    close(fpost);

  } else if (method == "GET"){
    // GET
    // Check URL pattern
    if (!strncmp(url, "/s/", 3))
    {
      int f404 = open("404Response.txt",O_RDONLY);
      int readSize = read(f404,buffer,1023);
      close(f404);
      write(fd,buffer,readSize);
    } else {
      // Getting the position of the old URL from the text file by decoding the new URL
      int oldURLPosition = decode(url);
      FILE* urlfile = fopen("urls.txt", "w");
      fseek(urlfile, oldURLPosition, SEEK_SET);
      // Read that URL into buffer
      char getBuffer[1024];
      int ch;
      int index = 0;
      while ((ch = fgetc(urlfile)) != EOF && ch != '\n') {
        getBuffer[index++] = ch;
      }
        getBuffer[index] = '\0'; // Null-terminate the string
        fclose(urlfile);

        // Send the response to the client
        char* str1 = "HTTP/1.1 301 Permanently Moved\r\nLocation: ";
        char* getResponse = strcat(str1,getBuffer);
        getResponse = strcat(getResponse,"\n");
        write(fd,getResponse,strlen(getResponse));
      }
  }
  close(fd);
}

void* workerThread(void *arg) {
  queue* q = (queue*) arg;
  while(1) {
    int fd = dequeue(q);
    serveRequest(fd);
  }
  return NULL;
}

int main() {
  // Set up the queue
  queue* q = queueCreate();

  // Set up the worker threads
  pthread_t w1,w2;
  pthread_create(&w1,NULL,workerThread,q);
  pthread_create(&w2,NULL,workerThread,q);

  // Create the socket
  int server_socket = socket(AF_INET , SOCK_STREAM , 0);
  if (server_socket == -1) {
    printf("Could not create socket.\n");
    return 1;
  }

  // Set the 'reuse address' socket option
  int on = 1;
  setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));

  //Prepare the sockaddr_in structure
  struct sockaddr_in server;
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons( 8888 );

  // Bind to the port we want to use
  if(bind(server_socket,(struct sockaddr *)&server , sizeof(server)) < 0) {
    printf("Bind failed\n");
    return 1;
  }
  printf("Bind done\n");

  // Mark the socket as a passive socket
  listen(server_socket , 3);

  // Accept incoming connections
  printf("Waiting for incoming connections...\n");
  while(1) {
    struct sockaddr_in client;
    int new_socket , c = sizeof(struct sockaddr_in);
    new_socket = accept(server_socket, (struct sockaddr *) &client, (socklen_t*)&c);
    if(new_socket != -1) {
      enqueue(q,new_socket);
    }
  }

  return 0;
}
