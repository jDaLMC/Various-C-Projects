#include <semaphore.h>

#define QUEUE_SIZE 16

typedef struct {
    int d[QUEUE_SIZE];//just and array of socket descriptors
    int front;
    int back;
    //mutex is binary (0 or 1)
    //semaphore - unsigned integer (could go from 0 to whatever). this keeps track of how many things are in the queue and if the queue is full it locks
    sem_t mutex;
    sem_t slots;
    sem_t items;
} queue;

queue* queueCreate();
void enqueue(queue* q,int fd);
int dequeue(queue* q);