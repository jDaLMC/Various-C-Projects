// Encode an int into six characters
void encode(unsigned int n,char* dest);
// Decode a set of six characters into an int
unsigned int decode(char* src);
