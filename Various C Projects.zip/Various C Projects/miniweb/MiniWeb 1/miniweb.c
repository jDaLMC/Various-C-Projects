#include <stdio.h>
#include <string.h>  //strlen
#include <sys/socket.h> //sockets api
#include <arpa/inet.h>  //inet_addr
#include <unistd.h>  //write
#include <fcntl.h>
#include <sys/stat.h>

// fd is short for file descriptor. this thing is a socket but its actually kinda like a file so we can read and write it
void serveRequest(int fd) {
  // Read the request
  char buffer[1024];
  int bytesRead = read(fd,buffer,1023);
  buffer[bytesRead] = '\0'; // add \0 at the end to treat the buffer like a string

  char method[16];
  char url[128];
  //sscanf reads info (2 strings) from a string (the buffer). the first string -> method buffer, second string -> url buffer
  sscanf(buffer,"%s %s",method,url);
  char fileName[128];
  strcpy(fileName,"www"); //go to the www folder inside the file
  strcat(fileName,url); //go to the link inside that www folder
  int filed = open(fileName,O_RDONLY); //actually open the file and read everything in there
  if(filed == -1) {
    // The user has a requested a file that we don't have.
    // Send them back the canned 404 error response.
    int f404 = open("404Response.txt",O_RDONLY); // open the error file, read the content
    int readSize = read(f404,buffer,1023); // send error content to buffer
    close(f404); //close file
    write(fd,buffer,readSize); //send the content of the buffer
  } else {
    //successfully connected to web
    const char* responseStatus = "HTTP/1.1 200 OK\n";
    //the content type just needs the correct file name (file extension not necessary, except if its .c) to get the right content
    const char* responseOther = "Connection: close\nContent-Type: text/html\n";
    // Get the size of the file
    char len[64];
    struct stat st;
    fstat(filed,&st);
    sprintf(len,"Content-Length: %d\n\n",(int) st.st_size);
    // Send the headers
    //writing stuff in the fd 'file' (because its a socket but its kinda like a file)
    write(fd,responseStatus,strlen(responseStatus));
    write(fd,responseOther,strlen(responseOther));
    write(fd,len,strlen(len));
    // Send the file
    while(bytesRead = read(filed,buffer,1023)) {
      write(fd,buffer,bytesRead);
    }
    close(filed);
  }
  close(fd);
}

int main() {
  // Create the socket used to connect, kinda like opening a file
  int server_socket = socket(AF_INET , SOCK_STREAM , 0); //integer identifies this specific socket
  if (server_socket == -1) {
    printf("Could not create socket.\n");
    return 1;
  }

  //Prepare the sockaddr_in structure
  struct sockaddr_in server;
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = INADDR_ANY;
  server.sin_port = htons( 8888 );

  // Bind to the port we want to use
  // send a pointer to that structure and how big it is
  // "bind" sets up server and sends back status code (negative means fail)
  if(bind(server_socket,(struct sockaddr *)&server , sizeof(server)) < 0) {
    printf("Bind failed\n");
    return 1;
  }
  printf("Bind done\n");

  // Mark the socket as a passive socket
  // waiting queue of 3 clients
  listen(server_socket , 3);

  // Accept incoming connections
  printf("Waiting for incoming connections...\n");
  while(1) {
    struct sockaddr_in client;
    int new_socket , c = sizeof(struct sockaddr_in);
    new_socket = accept(server_socket, (struct sockaddr *) &client, (socklen_t*)&c); // the accept functions literally accepts clients
    if(new_socket != -1)
      serveRequest(new_socket);
  }

  return 0;
}

// Control C is the command to kill current process