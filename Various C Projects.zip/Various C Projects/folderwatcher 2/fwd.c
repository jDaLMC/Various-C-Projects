#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>

static pthread_mutex_t logMutex = PTHREAD_MUTEX_INITIALIZER;

void watchFolder(void *arg) {

    struct ThreadParams *params = (struct ThreadParams *)arg;
    char *tag = params->tag;
    char *path = params->path;
    char *logFile = params->log;

    while (1) {
        DIR *folder = opendir(path);
        if (folder == NULL) {
            printf("Folder not found");
            return;
        }

        struct dirent *entry;
        entry = readdir(folder);

        struct stat fileStat;
        stat(path,&fileStat);
        time_t modifiedTime = fileStat.st_mtime;
        /** Missing an if statement here: check that the entry is a file and that it has been 
         *  modified since the last sleep.
        */
        // var/log/fwd.log
        pthread_mutex_lock(&logMutex); // Lock the mutex before logging
        fprintf(logFile, "%s %s %s", tag, entry->d_name, ctime(&modifiedTime));
        pthread_mutex_unlock(&logMutex); // Unlock the mutex after logging

        closedir(folder);
        sleep(300);
    }
}

struct ThreadParams {
    char tag[128];
    char path[128];
    FILE* log;
};

int countNewlines(FILE *file) {
    int newlineCount = 0;
    int ch;
    while ((ch = fgetc(file)) != EOF) {
        if (ch == '\n') {
            newlineCount++;
        }
    }
    return newlineCount;
}

int main() {
    pid_t pid = fork();

/** Missing: if(pid != 0) { **/
    FILE *pidFile = fopen("/run/fwd.pid", "w");
    fprintf(pidFile, "%d\n", pid);
    fclose(pidFile);

    exit(0);
/** Missing: } **/

// Open files
    FILE *configFile = fopen("/etc/fwd.conf", "r");
    FILE *logFile = fopen("/var/log/fwd.log", "a");

// Block SIGTERM
    sigset_t set;
    sigemptyset(&set);
    sigaddset(&set, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &set, NULL);

// Threads
    int numThreads = countNewlines(configFile);
    /** Call fseek() here to rewind back to the start of the config file. **/
    pthread_t *threadArray = (pthread_t *)malloc(numThreads * sizeof(pthread_t));

    char line[256];
    /** Using a single structure for all threads is not correct. What is likely to 
     *  happen here is that the loop below will overwrite the data in this structure
     *  before the thread has had a chance to read it.
     * 
     *  The correct approach is to make a separate structure for each thread.
    */
    struct ThreadParams params;
    params.log = logFile;
    int threadIndex = 0;

    while (fgets(line, sizeof(line), configFile) != NULL) {
        if (sscanf(line, "%s %s", params.tag, params.path) == 2) {
            pthread_create(&threadArray[threadIndex], NULL, watchFolder, (void *)&params);
            threadIndex++;
        }
    }

    fclose(configFile);

// Wait for SIGTERM
    int receivedSignal;
    sigwait(&set, &receivedSignal);

    if (receivedSignal == SIGTERM) {
        // Close the log file
        fclose(logFile);

        // Stop all running threads
        for (int i = 0; i < numThreads; i++) {
            /** This won't work, since you previously blocked the SIGTERM signal 
             *  from your threads. Call pthread_cancel() here instead.
            */
            pthread_kill(threadArray[i], SIGTERM);
        }

        // Free the thread array
        free(threadArray);
    }

    return 0;
}

/** 138/150 **/