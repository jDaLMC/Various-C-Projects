#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>

void watchFolder(const char *folderPath) {
    while (1) {
        DIR *folder = opendir(folderPath); 
        if (folder == NULL) {
            printf("Folder not found");
            return;
        }

        struct dirent *entry;
        entry = readdir(folder);

        struct stat fileStat; 
        stat(folderPath,&fileStat);
        time_t modifiedTime = fileStat.st_mtime;

        FILE *logFile = fopen("log.txt", "a");
        fprintf(logFile, "File: %s, Modified at: %s\n",entry->d_name, ctime(&modifiedTime));
        fclose(logFile);
        closedir(folder);
        sleep(300); 
    }
}

int main(int argc, char *argv[]) {
  char *pathURL = argv[1];
  watchFolder(pathURL);
}
