#include <stdio.h>
#include <stdlib.h>

/* this thing scans through the dictionary file, save the location of each word
and put the location information in a file of huge list onf ints
the index structure gives the word and the character
number to find a word at its exact location in the file */

int main() {
    FILE* f1 = fopen("words.txt","r");
    int wordCount = 1;
    char ch;
    while(!feof(f1)) {
        ch = fgetc(f1);
        if(ch == '\n') wordCount++;
    }

    FILE* f2 = fopen("index.idx","wb");
    fwrite(&wordCount,sizeof(int),1,f2);

    int* positions = (int*) malloc((wordCount+1)*sizeof(int));

    rewind(f1);

    wordCount = 0;
    positions[wordCount] = (int) ftell(f1);
    /* ftell tells the location in the file of the next character/available word
    this is how we get and store location of words*/

    while(!feof(f1)) {
        ch = fgetc(f1);
        if(ch == '\n') {
            wordCount++;
            positions[wordCount] = (int) ftell(f1);
        }
    }
    wordCount++;
    positions[wordCount] = (int) ftell(f1) + 1;
    fclose(f1);

    fwrite(positions,sizeof(int),wordCount+1,f2);
    /* fwrite is not when writing text but for writing data.
    parameters: position of data, size of data, how many we have, and destination file */

    fclose(f2);
    return 0;
}
