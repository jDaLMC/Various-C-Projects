#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef struct {
  int N; // Number of words in the the dictionary
  char** words; // Array of words. Star star means that it's a double pointer
} dictionary;

dictionary* loadDictionary(const char* fileName) { //function to read dictionary using name of file
    FILE* f = fopen(fileName,"r");
    //open file with fopen
    //(2 parameters: name of file, mode ("r-read", "w-write"))
    //returns FILE type pointer

    if(f == NULL)
    /*if opening file fails: it returns a null value.
    so checking if the value is null will help making sure that it opened correctly
    it can fail if we get the wrong file name or if the creator evokes permission*/
        return NULL;

    /* Count the words in the dictionary
    Look at each character and count the line breaks*/
    char ch;
    int lineCount = 0;
    while(!feof(f)) { //feof = file end of file
        ch = fgetc(f); // fgetc = get character (1 at a time)
        if(ch == '\n') lineCount++; //count a line if we see a line break
        /* note: in Unix, line breaks are almost always \n
        Original Mac: \r
        Windows: \r\n
        You can actually change: VSCode -> the file -> Status Line -> Select End of File Sequence*/
    }
    lineCount++; // The number of words is one more than the number of line breaks.
    rewind(f); // go back to start of file

    dictionary* d = (dictionary*) malloc(sizeof(dictionary)); // allocate memory with dictionary size
    d->N = lineCount; // dictionary size is number of words
    if(lineCount == 0) { // if for some reason, the number is 0
        d->words = NULL;
    } else { // reading each word
        d->words = (char**) malloc(lineCount * sizeof(char*)); // allocating memory for each word
        char buffer[64]; // each word is in this array of characters. then the words go back into 1 big array
        int n = 0;
        while(!feof(f)) { // while end of file (again)
            fscanf(f ,"%s",buffer); // f is just file, %s is for string, buffer is the destination
            char* word = (char*) malloc(strlen(buffer)+1);
            /* allocating memory with strlen (string length) = how long the word we just read is
            and store a special marker \0, so we need to plus an extra 1 byte */
            strcpy(word,buffer); //string copy (1st parameter = the place we're copying to, 2nd = copying from)
            d->words[n] = word; //throw word in dictionary
            n++;
        }
    }
    fclose(f); //close file

    return d;
}

void freeDictionary(dictionary* d) { //free all the memory we created in the last step
    for(int n = 0;n < d->N;n++)
        free(d->words[n]);
    free(d->words);
    free(d);
}

int searchDictionary(dictionary* d,const char* word) { //search function!! with binary search algorithm
    int start = 0;
    int end = d->N-1;
    while(start <= end) {
        int mid = (start+end)/2;
        const char* lookup = d->words[mid];
        int comp = strcmp(word,d->words[mid]);
        if(comp == 0) return mid;
        else if(comp < 0) end = mid -1;
        else start = mid + 1;
    }
    return -1;
}

void checkWords(dictionary* d,const char* fileName) {
    //check with the word in dictionary (word is given by search dictionary function)
  FILE* f = fopen(fileName,"r");
  if(f == NULL) {
    printf("Could not open data file.\n");
    return;
  }
  char line[256];
  char* word = NULL;
  const char* delims = " 0123456789!@#$&?%*+-/<>,.;:(){}[]\"\'\n\r\t";
  //delimators: punctuation, numbers, new lines, tabs, spaces

  while(!feof(f)) {
    fgets(line,255,f); //f get string
    word = strtok(line,delims);
    /*strtok is string token. take big text and break it into tokens/words. skip everything in the delims
     give strtok new line to read word from (in the first parameter)*/

    while(word != NULL) {
      int n = 0;
      while(word[n] != '\0') {
        word[n] = tolower(word[n]); //decapitalize word because dictionary is like that
        n++;
      }
      int loc = searchDictionary(d,word);
      if(loc == -1)
        printf("%s\n",word);
      word = strtok(NULL,delims);
      /* NULL means keep working with the line we already gave and
      get another word on that same line until there is no other word on that same line*/
    }
  }
  fclose(f); //close file
}



