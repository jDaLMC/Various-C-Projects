#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    int N;
    int* index;
    char* words;
} dictionary;

dictionary* loadDictionary(const char* indexName,const char* dictName) {
    //stat
    struct stat st;
    int warrsize = 0;
    if (stat(dictName, &st) == 0)
        warrsize = st.st_size;
    else
        warrsize = -1;

    dictionary* d = (dictionary*) malloc(sizeof(dictionary));

    //array of words
    d->words = (char*) malloc(warrsize+1);
    int fD = open(dictName, O_RDONLY);
    read(fD, d->words, warrsize);
    close(fD);
    d->words[warrsize] = '\0'; // last location is \0

    // replacing '\n's  with '\0'
    for (int i = 0; i < warrsize; i++) {
        if (d->words[i] == '\n') {
            d->words[i] = '\0';
        }
    }

    //array of indexes
    int f = open(indexName,O_RDWR);
    read(f,&(d->N),sizeof(int));

    d->index = (int*) malloc((d->N + 1) * sizeof(int));
    read(f,d->index,sizeof(int));
    close(f);

    return d;
}

void freeDictionary(dictionary* d) {
    free(d->words);
    free(d->index);
    free(d);
}

int searchDictionary(dictionary* d,const char* word) {
    int start = 0;
    int end = d->N-1;
    char* fileWord;

    while(start <= end) {
        int mid = (start+end)/2;
        fileWord = d->words + d->index[mid]; //because d->words points to the start of the array, the second term moves the pointer to the middle

        int comp = strcmp(word,fileWord);
        if(comp == 0) return mid;
        else if(comp < 0) end = mid -1;
        else start = mid + 1;
    }
    return -1;
}

void checkWords(dictionary* d,const char* fileName) {
    FILE* f = fopen(fileName,"r");
    if(f == NULL) {
        printf("Could not open data file.\n");
        return;
    }

    char line[256];
    char* word = NULL;
    const char* delims = " 0123456789!@#$&?%*+-/<>,.;:(){}[]\"\'\n\r\t";
    while(!feof(f)) {
        fgets(line,255,f);
        word = strtok(line,delims);
        while(word != NULL) {
            int n = 0;
            while(word[n] != '\0') {
                word[n] = tolower(word[n]);
                n++;
            }
            int loc = searchDictionary(d,word);
            if(loc == -1)
                printf("%s\n",word);
            word = strtok(NULL,delims);
        }
    }
    fclose(f);
}

int main() {
    dictionary* d = loadDictionary("index.idx","words.txt");
    if(d == NULL) {
        printf("Can not load dictionary.\n");
        return 1;
    }

    checkWords(d,"text.txt");

    freeDictionary(d);
    return 0;
}